// Databricks notebook source exported at Fri, 28 Oct 2016 02:53:48 UTC
import org.apache.spark.ml.Pipeline
import org.apache.spark.mllib.feature.PCA
import org.apache.spark.mllib.linalg.Vectors
import org.apache.spark.mllib.regression.LabeledPoint
import org.apache.spark.rdd.RDD
import org.apache.spark.mllib.util.MLUtils
import org.apache.spark.ml.classification.DecisionTreeClassificationModel
import org.apache.spark.ml.classification.DecisionTreeClassifier
import org.apache.spark.ml.evaluation.MulticlassClassificationEvaluator
import org.apache.spark.ml.feature.{IndexToString, StringIndexer, VectorIndexer}


val data = sc.textFile("/FileStore/tables/4hcu3xnl1477620884996/wine.data").map(line=>line.split(","))
val mlData = data.map(x =>(x(0).toInt,Vectors.dense( x(1).toDouble, x(2).toDouble,x(3).toDouble, x(4).toDouble, x(5).toDouble, x(6).toDouble, x(7).toDouble, x(8).toDouble, x(9).toDouble, x(10).toDouble, x(11).toDouble, x(12).toDouble, x(13).toDouble)))
val features = data.map(x => Vectors.dense( x(1).toDouble, x(2).toDouble,x(3).toDouble, x(4).toDouble, x(5).toDouble, x(6).toDouble, x(7).toDouble, x(8).toDouble, x(9).toDouble, x(10).toDouble, x(11).toDouble, x(12).toDouble, x(13).toDouble))
val pca = new PCA(2).fit(features)
val projected = data.map(x => (x(0).toInt, pca.transform(Vectors.dense( x(1).toDouble, x(2).toDouble,x(3).toDouble, x(4).toDouble, x(5).toDouble, x(6).toDouble, x(7).toDouble, x(8).toDouble, x(9).toDouble, x(10).toDouble, x(11).toDouble, x(12).toDouble, x(13).toDouble))))

val df = sqlContext.createDataFrame(projected).toDF("label", "features")
val convertedVecDF = MLUtils.convertVectorColumnsToML(df)


// Index labels, adding metadata to the label column.
// Fit on whole dataset to include all labels in index.
val labelIndexer = new StringIndexer()
  .setInputCol("label")
  .setOutputCol("indexedLabel")
  .fit(convertedVecDF)
// Automatically identify categorical features, and index them.
val featureIndexer = new VectorIndexer()
  .setInputCol("features")
  .setOutputCol("indexedFeatures")
  .setMaxCategories(4) // features with > 4 distinct values are treated as continuous.
  .fit(convertedVecDF)

// Split the data into training and test sets (30% held out for testing).
val Array(trainingData, testData) = convertedVecDF.randomSplit(Array(0.7, 0.3))

// Train a DecisionTree model.
val dt = new DecisionTreeClassifier()
  .setLabelCol("indexedLabel")
  .setFeaturesCol("indexedFeatures")

// Convert indexed labels back to original labels.
val labelConverter = new IndexToString()
  .setInputCol("prediction")
  .setOutputCol("predictedLabel")
  .setLabels(labelIndexer.labels)

// Chain indexers and tree in a Pipeline.
val pipeline = new Pipeline()
  .setStages(Array(labelIndexer, featureIndexer, dt, labelConverter))

// Train model. This also runs the indexers.
val model = pipeline.fit(trainingData)

// Make predictions.
val predictions = model.transform(testData)

// Select example rows to display.
//predictions.select("predictedLabel", "label", "features").show(5)

// Select (prediction, true label) and compute test error.
val evaluator1 = new MulticlassClassificationEvaluator()
  .setLabelCol("indexedLabel")
  .setPredictionCol("prediction")
  .setMetricName("accuracy")
val accuracy = evaluator1.evaluate(predictions)
println("Test Error = " + (1.0 - accuracy))


// Select (prediction, true label) and compute test error.
val evaluator2 = new MulticlassClassificationEvaluator()
  .setLabelCol("indexedLabel")
  .setPredictionCol("prediction")
  .setMetricName("f1")
val f1 = evaluator2.evaluate(predictions)
println("F1 metric = " + f1)


// Select (prediction, true label) and compute test error.
val evaluator3 = new MulticlassClassificationEvaluator()
  .setLabelCol("indexedLabel")
  .setPredictionCol("prediction")
  .setMetricName("weightedPrecision")
val weightedPrecision = evaluator3.evaluate(predictions)
println("weighted Precision= " + weightedPrecision)

//val treeModel = model.stages(2).asInstanceOf[DecisionTreeClassificationModel]
//println("Learned classification tree model:\n" + treeModel.toDebugString)

// COMMAND ----------


