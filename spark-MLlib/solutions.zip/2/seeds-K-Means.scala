// Databricks notebook source exported at Fri, 28 Oct 2016 04:45:12 UTC
import org.apache.spark.mllib.clustering.{KMeans, KMeansModel}
import org.apache.spark.mllib.linalg.Vectors

// Load and parse the data
val data = sc.textFile("/FileStore/tables/0ukgi2a91477624812886/seeds_dataset.txt").map(line=>line.split("\\s+"))
val parsedData = data.map(x => Vectors.dense(x(0).toDouble, x(1).toDouble, x(2).toDouble, x(3).toDouble, x(4).toDouble, x(5).toDouble, x(6).toDouble)).cache()

// Cluster the data into two classes using KMeans
val numClusters = 3
val numIterations = 100
val clusters = KMeans.train(parsedData, numClusters, numIterations)

// Evaluate clustering by computing Within Set Sum of Squared Errors
val WSSSE = clusters.computeCost(parsedData)
println("Within Set Sum of Squared Errors = " + WSSSE)



// Save and load model
//clusters.save(sc, "target/org/apache/spark/KMeansExample/KMeansModel")
//val sameModel = KMeansModel.load(sc, "target/org/apache/spark/KMeansExample/KMeansModel")

// COMMAND ----------


