// Databricks notebook source exported at Fri, 28 Oct 2016 04:25:45 UTC
// Databricks notebook source exported at Thu, 27 Oct 2016 23:41:00 UTC
import org.apache.spark.ml.regression.LinearRegression
import org.apache.spark.ml.linalg.{Vector,Vectors}

// Load training data
val data = sc.textFile("/FileStore/tables/q2k7uwbl1477628496448/airfoil_self_noise.dat").map(x=>(x(5).toDouble,Vectors.dense(x(0).toDouble,x(1).toDouble,x(2).toDouble,x(3).toDouble,x(4).toDouble))).toDF("label","features")

val lr = new LinearRegression()
  .setMaxIter(10)
  .setRegParam(0.3)
  .setElasticNetParam(0.8)

// Fit the model
val lrModel = lr.fit(data)

println(s"Coefficients: ${lrModel.coefficients} Intercept: ${lrModel.intercept}")

val trainingSummary = lrModel.summary

println(s"numIterations: ${trainingSummary.totalIterations}")
println(s"objectiveHistory: ${trainingSummary.objectiveHistory.toList}")
//trainingSummary.residuals.show()
println(s"RMSE: ${trainingSummary.rootMeanSquaredError}")
println(s"r2: ${trainingSummary.r2}")
println(s"explainedVariance: ${trainingSummary.explainedVariance}")


// COMMAND ----------


